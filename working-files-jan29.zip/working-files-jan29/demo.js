document.getElementById("test2").innerHTML = "This is our first session of Web Development course";

function myFunction(){

    document.getElementById("test3").style.color = "red";
    document.getElementById("test3").style.fontSize = "25px";
    document.getElementById("test3").style.backgroundColor = "lightblue";
}


function secondFunction(){

    document.getElementById("test11").style.fontWeight = 900;
    document.getElementById("test11").style.fontSize = "50px";
}

function calcSum(price1, price2){

    //document.getElementById("test12").innerHTML = price1 + price2;
    return price1 + price2;

}

document.getElementById("test20").onchange = function(){

    document.getElementById("test20").value = 20;
}

calcSum(12,24);

document.getElementById("test13").onclick = function(){
    document.getElementById("test13").style.color = "blue";
    document.getElementById("test13").style.fontSize = "25px";
}

function firstFunction(){

    alert("Hello there!");
}

function secFunction(){

    alert("Hello again!");
}

// window.onload = firstFunction;
// window.onload = secFunction;

window.addEventListener("load",firstFunction);
window.addEventListener("load",secFunction);


function funFunction(){

    document.getElementById("test4").src = "nature.jpg";
}

function fourthFunction(){

    var element = 45;
}


var cars1 = "Nissan, Volvo, Toyota";
var cars2 = "Ford";
cars1.substring(7);
cars2.replace("Ford","Volvo");

var num1 = 34;
num1.toString();


var price1 = 40;
var price2 = 20;
let price3 = price1 + price2;
const fullName = "John Doe";

let lName;

var number1 = 23;
var number1 = 43;
var number2 = 45;
// here number2 is 45

{

    var number2 = 67;
    // here number 67
}

// here number2 67
let fName1 = "John Doe";
//let fName1 = "Mary Smith";

let fName2 = "Lisa Kay";

// here fName2 is Lisa Kay


{

    let fName2 = "David Kay";
    // here fName2 is David Kay
}

// here fName2 is Lisa Kay

const PI = 3.1456788899;
//const PI;

document.write(price3);
document.writ("<br>");
document.write("<hr>");
document.write(fullName);

function function3() {

    document.getElementById("test6").style.color = "blue";
}

document.getElementById("test10").value = price1;